import datetime

from firebase_admin import messaging
from flask import Flask, render_template

app = Flask(__name__)
TOKENS = [] # client tokens in memory

@app.route("/")
def index():
    return render_template('index.html')


@app.route('/message/',methods=['POST', "PUT"])
def message():
    if request.method == "POST":
        print("request.data", request.data)
        return render_template('index.html')
    else:
        print("request.data", request.data)
        print("send message to0 clients")
        for token in TOKENS:
            message = messaging.Message(
                data={
                    'score': '850',
                    'time': '2:45',
                },
                token=token,
            )
            response = messaging.send(message)
    return render_template('index.html')

if __name__ == '__main__':
    app.run()

# registration_token = 'YOUR_REGISTRATION_TOKEN'



# # See documentation on defining a message payload.
# message = messaging.Message(
#     data={
#         'score': '850',
#         'time': '2:45',
#     },
#     token=registration_token,
# )

# # Send a message to the device corresponding to the provided
# # registration token.
# response = messaging.send(message)
# Response is a message ID string.
# print('Successfully sent message:', response)
